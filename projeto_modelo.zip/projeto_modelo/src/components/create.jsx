import React from 'react'
import { Button, Checkbox, Form } from 'semantic-ui-react'

const FormExampleForm = () => (
  <Form className='create-form'>
    <Form.Field>
      <label>Informe o Nome:</label>
      <input placeholder='Primeiro Nome' />
    </Form.Field>
    <Form.Field>
      <label>Informe o Sobrenome:</label>
      <input placeholder='Ultimo Nome' />
    </Form.Field>
    <Form.Field>
      <Checkbox label='Eu Aceito os Termos e Condições!' />
    </Form.Field>
    <Button type='submit'>Submit</Button>
  </Form>
)

export default FormExampleForm